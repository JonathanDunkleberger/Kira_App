"use client";
export default function StreakIndicator() { return null; }
