export default function EmptyState() {
  return (
    <div className="text-center text-gray-400">
      <p>Hold the mic to start talking to Kira.</p>
    </div>
  );
}
