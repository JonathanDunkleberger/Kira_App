// This file is no longer used by the Edge function.
// The prompt has been moved directly into /api/utterance/route.ts for reliability.
// This file can be deleted after confirming the fix.

export {};